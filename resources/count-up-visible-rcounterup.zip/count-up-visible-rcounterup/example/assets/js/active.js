(function($) {
    'use strict';

    $('.count-num').rCounter();
})(jQuery);