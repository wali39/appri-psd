# rCounterup
Jquery Counterup Plugin

#load rprogressbar js
<pre>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
 <script src="assets/js/jquery.rcounter.js"></script>
</pre>
    
#if you don't have jquery script than use like below order    
<pre>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/3.1.0/jquery-migrate.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
 <script src="assets/js/jquery.rcounter.js"></script>
</pre>
#activate rProgressbar
<pre>
 $('.className').rCounter ();
</pre>
#available options
 duration: 20,
</pre>
